<?php
$servernomi_db = '';
$usernomi_db = '';
$parol_db = '';
$dbnomi_db = '';
$baza = new mysqli($servernomi_db, $usernomi_db, $parol_db, $dbnomi_db);