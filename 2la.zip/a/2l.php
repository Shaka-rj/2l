<?php

class to_64{
    public $alphabet = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_";
    
    public $alphabet_length = strlen($alphabet);
    
    function encode($number = 0){
        $text = '';
        while ($number > $this->alphabet_length){
            $qoldiq = $number % $alphabet_length;
            $text = $alphabet[$qoldiq] . $text;
            $number = floor($number / $this->alphabet_length);
        }
        return $text;
    }
    
    function decode($strig){
        
    }
}


$a = new to_64();
echo $a->encode(1341434);